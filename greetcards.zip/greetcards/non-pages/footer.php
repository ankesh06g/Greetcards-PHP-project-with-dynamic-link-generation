    <footer>
        <div class="footer">
            <center>
                <a href="https://www.facebook.com/CompRepository-457159251436485"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.youtube.com/channel/UCajCBee6FiNo-gRHoGd-PCA"><i class="fab fa-youtube"></i></a>
                <a href="https://twitter.com/Ankesh_AAG"><i class="fab fa-twitter"></i></a>
                    <a href="https://github.com/ankesh06g"><i class="fab fa-github"></i></a>
                    <a href="https://www.linkedin.com/in/ankesh-gaikwad-4a2701134/"><i class="fab fa-linkedin-in"></i></a><br>
                <span class="copyright">All copyrights reserved © GreetCards 2018
                </span>
            </center>
        </div>
    </footer>
    <script src="http://greetcards.tk/repository/js/gc.js" type="text/javascript"></script>
    <script src="http://greetcards.tk/repository/js/jquery.min.js" type="text/javascript"></script>
    <script src="http://greetcards.tk/repository/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  </body>
</html>