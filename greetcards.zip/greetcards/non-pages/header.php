<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="http://greetcards.tk/repository/images/logo.png">
        <!-- Chrome, Firefox OS and Opera -->
        <meta name="theme-color" content="#007BA9">
        <!-- Windows Phone -->
        <meta name="msapplication-navbutton-color" content="#007BA9">
        <!-- iOS Safari -->
        <meta name="apple-mobile-web-app-status-bar-style" content="#007BA9">
        <link rel="stylesheet" href="http://greetcards.tk/repository/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
        <link rel="stylesheet" href="http://greetcards.tk/repository/css/gc.css">
        <link href="https://fonts.googleapis.com/css?family=Great+Vibes" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Yellowtail" rel="stylesheet">
        <title>GreetCards</title>
    </head>
    <body>
        <div class="container-fliud">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
              <img id="myImg" src="http://greetcards.tk/repository/images/logo.png" width="60" height="60" class="d-inline-block align-top" alt="">
              <a class="navbar-brand logo" href="http://greetcards.tk">
                 &nbsp;&nbsp;GreetCards
              </a>
              <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link" href="http://localhost/back-greetcards/how-to">How to use <i class="fas fa-question"></i></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="http://localhost/back-greetcards/create">create <i class="fas fa-plus"></i> </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="http://localhost/back-greetcards/stat">Stats <i class="fas fa-chart-line"></i> </a>
                  </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                  <li class="nav-item active">
                    <a class="nav-link float-left" href="https://www.facebook.com/CompRepository-457159251436485"><i class="fab fa-facebook-f"></i></a>
                    <a class="nav-link float-left" href="https://www.youtube.com/channel/UCajCBee6FiNo-gRHoGd-PCA"><i class="fab fa-youtube"></i></a>
                    <a class="nav-link float-left" href="https://twitter.com/Ankesh_AAG"><i class="fab fa-twitter"></i></a>
                    <a class="nav-link float-left" href="https://github.com/ankesh06g"><i class="fab fa-github"></i></a>
                    <a class="nav-link float-left" href="https://www.linkedin.com/in/ankesh-gaikwad-4a2701134/><i class="fab fa-linkedin-in"></i></a>
                  </li>
                </ul>
              </div>
            </nav>
            <div id="myModal" class="modal">
              <span class="close">&times;</span>
              <img class="modal-content" id="img01">
              <div id="caption"></div>
            </div>
