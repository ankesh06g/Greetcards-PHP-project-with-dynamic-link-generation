<?php

header("location: http://greetcards.tk");

?>