<?php 
    if( isset($_SESSION['message']) AND !empty($_SESSION['message']))
        {
            echo "<link rel='stylesheet' href='http://greetcards.tk/repository/css/forms.css' type='text/css'>
                    <div class='container-fluid'>
                        <div class='row'>
                            <div class='col-sm-3'></div>
                            <div class='col-sm-6'>
                                <div class='box'>";
                                    echo $_SESSION['message']; 
                    echo "      </div>
                            </div>
                            <div class='col-sm-3'></div>
                        </div>
                    </div>";
        }     
    else
    {
        header("location: http://greetcards.tk");
    }
    $_SESSION['message']='';
    $_SESSION['share_link']='';
?>