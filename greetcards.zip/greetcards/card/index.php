<?php
include '../non-pages/header.php';
require '../database/db.inc.php';
$_SESSION['message']='';
$_SESSION['share_link']='';

$gc_to = $_GET['to'];
$gc_date = $_GET['date'];
$gc_time = $_GET['time'];

$sql = "SELECT * FROM cards WHERE `to`='$gc_to' and `time`='$gc_time' and `date`='$gc_date'";
$result = mysqli_query($mysqli,$sql);
$resultCheck = mysqli_num_rows($result);
if($resultCheck > 0)
{
    if ($row = mysqli_fetch_array($result))
    {
      $gc_id = $row['gc_id'];
        $gc_from = $row['from'];
        $gc_wishes = $row['wishes'];
        $gc_message = $row['message'];
        $t_id = $row['t_id'];
        $gc_views = $row['views'];
        
        $sql = "SELECT * FROM themes WHERE `t_id`='$t_id';";
        $result = mysqli_query($mysqli,$sql);
        $resultCheck = mysqli_num_rows($result);
        if($resultCheck > 0)
        {
            if ($row = mysqli_fetch_array($result))
            {
              $gc_theme = 'data:image/jpeg;base64,'.base64_encode($row['theme']);
            }
        }
    }
    require 'card.inc.php';
}
else{
    $_SESSION['message'] = '
    <div class="alert alert-warning">
    <strong>Warning!</strong> Something goes wrong please try again!.
    </div>';
    require  '../pages/message.php';
}
?>
