
<div class="container">
    <div class="row">
        <div class="card" style="background-image: url('<?php echo "$gc_theme"; ?>');">
            <div class="row">
                <div class="col-sm-12 whishes">
                    <?php echo "$gc_wishes"; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 message">
                    "<?php echo "$gc_message"; ?>"
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="row">
                        <div class="col-sm-12 from">
                            <?php echo "$gc_from"; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 to-2">
                            to
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 to">
                            <?php echo "$gc_to"; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>