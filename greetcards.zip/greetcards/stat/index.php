<?php
include '../non-pages/header.php';
require '../database/db.inc.php';
?>

<div class="container">
  <center><span class="display-4">Statistics</span><br><br>   </center>
  <span class="display-4">Overall</span>
  <div class="row">
  <div class="col-sm-4"><br><br>
        <h1>Total views</h1>
        <?php
            $sql = "select count(*) from status;";
            $result = mysqli_query($mysqli,$sql);
            if($row = mysqli_fetch_array($result))
            {
                $o_t = $row['count(*)'];
            }
         ?>
        <span class="display-4"><?php echo $o_t; ?></span>
  </div>
  <div class="col-sm-8">
  <table class="table">
        <?php 
            $sql = "select *, count(*) from status group by pid;";
            $result = mysqli_query($mysqli,$sql);
            $opt = "<thead>
                      <tr>
                        <th>Pid</th>
                        <th>Page</th>
                        <th>count</th>
                      </tr>
                    </thead>
                    <tbody>";
           while($row = mysqli_fetch_array($result))
           {
                $opt .= "<tr>
                            <td>{$row['pid']}</td>
                            <td>{$row['page']}</td>
                            <td>{$row['count(*)']}</td>
                        </tr>";
            }
            $opt .= "
                    </tbody>
                 </tbody>";  
            echo $opt;
         ?>
  </table>
  </div></div><br><br>
  <span class="display-4">Today</span>
  <div class="row">
  <div class="col-sm-8">
  <table class="table">
        <?php 
            $check_date = date('Y-m-d');
            $sql = "select *, count(*) from status where date='$check_date' group by pid ;";
            $result = mysqli_query($mysqli,$sql);
            $opt = "<thead>
                      <tr>
                        <th>Pid</th>
                        <th>Page</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Count</th>
                      </tr>
                    </thead>
                    <tbody>";
           while($row = mysqli_fetch_array($result))
           {
                $opt .= "<tr>
                            <td>{$row['pid']}</td>
                            <td>{$row['page']}</td>
                            <td>{$row['date']}</td>
                            <td>{$row['time']}</td>
                            <td>{$row['count(*)']}</td>
                        </tr>";
            }
            $opt .= "
                    </tbody>
                 </tbody>";  
            echo $opt;
         ?>
  </table>
  </div>
  <div class="col-sm-4"><br><br>
        <h1>Todays Total views</h1>
         <?php 
            $check_date = date('Y-m-d');
            $sql = "select count(*) from status where date='$check_date' ;";
            $result = mysqli_query($mysqli,$sql);
            if($row = mysqli_fetch_array($result))
            {
                $t_t = $row['count(*)'];
            }
         ?>
        <span class="display-4"><?php echo $t_t; ?></span>
  </div>
  </div><br><br>
  <span class="display-4">Yesterday</span>
  <div class="row">
  <div class="col-sm-4"><br><br>
        <h1>Yesterdays Total Views</h1>
        <?php 
            $check_date = date('Y/m/d',strtotime("-1 days"));
            $sql = "select count(*) from status where date='$check_date' ;";
            $result = mysqli_query($mysqli,$sql);
            if($row = mysqli_fetch_array($result))
            {
                $y_t = $row['count(*)'];
            }
         ?>
        <span class="display-4"><?php echo $y_t; ?></span>
  </div>
  <div class="col-sm-8">
  <table class="table">
        <?php 
            $check_date = date('Y/m/d',strtotime("-1 days"));
            $sql = "select *, count(*) from status where date='$check_date' group by pid ;";
            $result = mysqli_query($mysqli,$sql);
            $opt = "<thead>
                      <tr>
                        <th>Pid</th>
                        <th>Page</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Count</th>
                      </tr>
                    </thead>
                    <tbody>";
           while($row = mysqli_fetch_array($result))
           {
                $opt .= "<tr>
                            <td>{$row['pid']}</td>
                            <td>{$row['page']}</td>
                            <td>{$row['date']}</td>
                            <td>{$row['time']}</td>
                            <td>{$row['count(*)']}</td>
                        </tr>";
            }
            $opt .= "
                    </tbody>
                 </tbody>";  
            echo $opt;
         ?>
  </table>
</div>
</div>
</div>

<?php
    $c_date = date('Y-m-d');
    $c_time = date("H:i:s");
    $sql = "INSERT INTO `status`(`date`, `time`, `page`, `pid`) VALUES ('$c_date', '$c_time', 'greetcards.tk/stat', 'p5');"; 
    mysqli_query($mysqli,$sql);
include '../non-pages/footer.php';
?>