    <?php
    include '../non-pages/header.php';
    require '../database/db.inc.php';
    ?>
        <div class="container"><br>
    <div class="row">
        <div class="col-sm-4"><br><br>
            <span class="display-4">1. Add Details</span>
        </div>
        <div class="col-sm-8">
            <img src="../repository/images/th1.png" class="img-fluid">
        </div>
    </div><br>
    <div class="row">
        <div class="col-sm-4"><br><br>
            <span class="display-4">2. Choose Theme</span>
        </div>
        <div class="col-sm-8">
            <img src="../repository/images/th2.png" class="img-fluid">
        </div>
    </div><br>
    <div class="row">
        <div class="col-sm-4"><br><br>
            <span class="display-4">3. Copy Your Link</span>
        </div>
        <div class="col-sm-8">
            <img src="../repository/images/th3.png" class="img-fluid">
        </div>
    </div><br>
    <div class="row">
        <div class="col-sm-4"><br><br>
            <span class="display-4">4. Share or Check</span>
        </div>
        <div class="col-sm-8">
            <img src="../repository/images/th4.png" class="img-fluid">
        </div>
    </div><br>
</div>
        <div class="fixed-bottom">
            <a href="http://greetcards.tk/create">
                <i class="fas fa-plus-circle"></i>
            </a>
        </div> 
    <?php
    
    $c_date = date('Y-m-d');
    $c_time = date("H:i:s");
    $sql = "INSERT INTO `status`(`date`, `time`, `page`, `pid`) VALUES ('$c_date', '$c_time', 'greetcards.tk/how-to', 'p2');"; 
    mysqli_query($mysqli,$sql);
    
    include '../non-pages/footer.php';
    ?>