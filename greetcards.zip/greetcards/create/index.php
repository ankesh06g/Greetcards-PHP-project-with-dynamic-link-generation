<?php
include '../non-pages/header.php';
require '../database/db.inc.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['submit'])) { 

        require 'create.inc.php';
        
    }
}

?>
<link rel="stylesheet" href="http://greetcards.tk/repository/css/forms.css" type="text/css">
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <div class="box">
                <div class="logo logo-m">
                    GreetCards
                </div>
                <span class="display-4">Create Greeting</span>
                <h4 class="light">Create your own greeting card for a special person</h4>
                <form method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-sm-6"><br>
                            <div class="input-box">
                                <input type="text" name="gc_from" autocomplete="off" required/>
                                <label> From *</label>
                                <span class="light">e.g. Oliver</span>
                            </div>
                        </div>
                        <div class="col-sm-6"><br>
                            <div class="input-box">
                                <input type="text" name="gc_to" autocomplete="off" required/>
                                <label>To *</label>
                                <span class="light">e.g. Charlie</span>
                            </div>
                        </div>
                    </div><br><br>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="input-box">
                                <input type="text" name="gc_wishes" autocomplete="off" required/>
                                <label>Wishesh *</label>
                                <span class="light">e.g. Happy birthday...!</span>
                            </div>
                        </div>
                    </div><br><br>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="input-box">
                                <input type="text" name="gc_message" autocomplete="off" required/>
                                <label>Message *</label>
                                <span class="light">e.g. Wishing you a day that is as special in every way as you are! ...</span>
                            </div>
                        </div>
                    </div><br><br>
                    <div class="row">
                        <div class="col-sm-12">
                            <style>
                                .modal-backdrop {
                                    /* bug fix - no overlay */    
                                    display: none;    
                                }
                                /* theme window*/
                                .theme-toolbar input[type="radio"] {
                                  display: none;
                                }
                                .theme-toolbar label {
                                  display: inline-block;
                                  cursor: pointer;
                                }
                                .theme-toolbar label{
                                    width: 100%;
                                }
                                .theme-toolbar .col-sm-4{
                                    padding: 0;
                                }
                                .fa-check-circle{
                                    color: #00B8E1;
                                    left: 20px;
                                    position: absolute;
                                    top: 10px;
                                    bottom: 0;
                                    left: 10px;
                                    right: 0;
                                    font-size: 30px;
                                    display: none;
                                }
                                .col-sm-4:hover label {
                                  background-color: #00B8E1;
                                }
                                .theme-toolbar input[type="radio"]:checked+label {
                                  background-color: #00B8E1;
                                }
                                .theme-toolbar input[type="radio"]:checked+ label .fa-check-circle{
                                    display: block;
                                
                                }
                                .theme-toolbar .col-sm-4:hover .fa-check-circle{
                                    display: block;
                                }
                                .theme-toolbar .col-sm-4 img{
                                    padding: 2px 2px;
                                }
                                                        </style>
                            <label class="btn btn-primary" data-toggle="collapse" data-target="#demo">choose theme</label><br><br>
                            <div id="demo" class="collapse">
                                <div class="container-fluid">
                                    <div class="theme-toolbar">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <input type="radio" id="10" name="gc_theme" value="10" required>
                                                <label for="10">
                                                    <img src="../repository/images/a1.png" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="11" name="gc_theme" value="11">
                                                <label for="11">
                                                    <img src="../repository/images/a2.png" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="12" name="gc_theme" value="12">
                                                <label for="12">
                                                    <img src="../repository/images/a3.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="13" name="gc_theme" value="13">
                                                <label for="13">
                                                    <img src="../repository/images/a4.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="14" name="gc_theme" value="14">
                                                <label for="14">
                                                    <img src="../repository/images/a5.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="15" name="gc_theme" value="15">
                                                <label for="15">
                                                    <img src="../repository/images/a6.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="16" name="gc_theme" value="16">
                                                <label for="16">
                                                    <img src="../repository/images/a7.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="17" name="gc_theme" value="17">
                                                <label for="17">
                                                    <img src="../repository/images/a8.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="18" name="gc_theme" value="18">
                                                <label for="18">
                                                    <img src="../repository/images/a9.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="19" name="gc_theme" value="19">
                                                <label for="19">
                                                    <img src="../repository/images/a10.png" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="20" name="gc_theme" value="20">
                                                <label for="20">
                                                    <img src="../repository/images/a11.png" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="21" name="gc_theme" value="21">
                                                <label for="21">
                                                    <img src="../repository/images/a12.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="22" name="gc_theme" value="22">
                                                <label for="22">
                                                    <img src="../repository/images/a13.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div><div class="col-sm-4">
                                                <input type="radio" id="23" name="gc_theme" value="23">
                                                <label for="23">
                                                    <img src="../repository/images/a14.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="24" name="gc_theme" value="24">
                                                <label for="24">
                                                    <img src="../repository/images/a15.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="radio" id="25" name="gc_theme" value="25">
                                                <label for="25">
                                                    <img src="../repository/images/a16.jpg" class="img-fluid theme-image">
                                                    <i class="far fa-check-circle"></i>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><br><br>
                    <div class="row">
                        <div class="next-button">
                            <button type="submit" name="submit" id="submit" value="submit" class="btn btn-primary">Next</button>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
        <div class="col-sm-3"></div>
    </div>
</div>  
<?php

    $c_date = date('Y-m-d');
    $c_time = date("H:i:s");
    $sql = "INSERT INTO `status`(`date`, `time`, `page`, `pid`) VALUES ('$c_date', '$c_time', 'greetcards.tk/create', 'p3');"; 
    mysqli_query($mysqli,$sql);
include '../non-pages/footer.php';
?>