<?php
    include_once '../database/db.inc.php';
    $_SESSION['message']='';
    $_SESSION['share_link']='';
    if(isset($_POST["submit"]))
    {
        $gc_from = mysqli_real_escape_string($mysqli,$_POST['gc_from']);
        $gc_to = mysqli_real_escape_string($mysqli,$_POST['gc_to']);
        $gc_wishes = mysqli_real_escape_string($mysqli,$_POST['gc_wishes']);
        $gc_message = mysqli_real_escape_string($mysqli,$_POST['gc_message']);
        $gc_theme = mysqli_real_escape_string($mysqli,$_POST['gc_theme']);
        $date = date('Y-m-d');
        $time = date("H:i:s");
        $sql = "INSERT INTO `cards`(`from`, `to`, `wishes`, `message`, `t_id`, `date`, `time`) VALUES ('$gc_from', '$gc_to', '$gc_wishes', '$gc_message', '$gc_theme', '$date', '$time');";
        if(mysqli_query($mysqli,$sql))
        {
              $_SESSION['share_link'] = "http://localhost/back-greetcards/card/index.php?to=".$gc_to."&date=".$date."&time=".$time;
             $_SESSION['message'] = "
                            <span class='display-4'>hooray...</span></br></br>
                            <div class='alert alert-success'>
                                <strong>Success!</strong> Your card has been created!
                            </div>
                            <span class='light'>Now share with your friend...</span></br></br>
                            <div class='row'>
                                <div class='col-sm-12'>
                                    <div class='input-box'>
                                        <input type='text' value='{$_SESSION['share_link']}' id='myInput'>
                                        <button class='btn btn-primary' onclick='myFunction()'>Copy</button>
                                        <script>
                                        function myFunction() {
                                          var copyText = document.getElementById('myInput');
                                          copyText.select();
                                          document.execCommand('copy');
                                        }
                                        </script>
                                    </div>
                                </div>
                            </div></br>
                            <div class='alert alert-warning'>
                            <strong>Warning!</strong> This link will not be gate back again . So, please save.
                            </div>";
             require '../pages/message.php';
        }
        else{
            $_SESSION['message'] = '
            <div class="alert alert-warning">
            <strong>Warning!</strong> Something goes wrong please try again!.
            </div>';
            require '../pages/message.php';
        }
    }    