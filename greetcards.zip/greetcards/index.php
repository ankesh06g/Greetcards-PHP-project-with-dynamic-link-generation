<?php
include 'non-pages/header.php';
require 'database/db.inc.php';
?>.
<style>
    .addhead{
        text-align: center;
        
    } 
</style>
<div class="container-fluid"><br>
     <div class="row">
        <div class="col-sm-12">
            <h1 class="addhead "> My References </h1>
        </div>
    </div><br>
    <div class="row">
        <div class="col-md-1 center" >
            <div class = "myadd ">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=0070223629&asins=0070223629&linkId=424b260d84efddb225d2323b66a8eb81&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
                </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=9332582734&asins=9332582734&linkId=cb7722ec8b245a11ed6253584bc6326c&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
                </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=0070701946&asins=0070701946&linkId=6a3b4ca2d79540eff748e0f0e60f9d27&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
                </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=9352130154&asins=9352130154&linkId=040979c80ad9c9325b03e3fe285a4472&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
            </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=1782175911&asins=1782175911&linkId=aa3dc0d46b75849c39b2ff7bfb72f89a&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
    </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=9332501998&asins=9332501998&linkId=eefc694b1338cf96da61fc5142d58857&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
            </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=1782175911&asins=1782175911&linkId=aa3dc0d46b75849c39b2ff7bfb72f89a&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
              </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=B078ZKZFZK&asins=B078ZKZFZK&linkId=b1c5c209e5030d60a8448a6db8f2493f&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
            </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=0070701946&asins=0070701946&linkId=6a3b4ca2d79540eff748e0f0e60f9d27&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
    </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=8183335152&asins=8183335152&linkId=5eeb5fc912289a4aaa702448ed9142ee&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
            </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
                <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=B00LX6D0PM&asins=B00LX6D0PM&linkId=e39f05e65af4b49cdce0b2f74d3c4731&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
            </iframe>
            </div>
        </div>
        <div class="col-md-1 center" >
            <div class = "myadd">
            <iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=8178063093&asins=8178063093&linkId=bdef4d558090815ae374683d963c8c9a&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
            </iframe>
            </div>
        </div>
    </div><br>
    <div class="row">  
        <div class="col-sm-4 "></div>
        <div class="col-sm-4 center">
                <h1 class="addhead"> My Favorit Book </h1><br>
                <center><iframe style="width:120px;height:240px;" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" src="//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ac&ref=qf_sp_asin_til&ad_type=product_link&tracking_id=ankesh0514-21&marketplace=amazon&region=IN&placement=1118907442&asins=1118907442&linkId=3d3a8799d7a20715bece483212f202a6&show_border=false&link_opens_in_new_window=true&price_color=333333&title_color=0066c0&bg_color=ffffff">
                    </iframe></center>
        </div>
        <div class="col-sm-4 "></div>
    </div><br>
    <div class="row">
        <div class="col-sm-12">
            <img src="repository/images/1.png" class="mx-auto d-block img-fluid">
        </div>
    </div><br>
    <div class="row">
        <div class="col-sm-12">
            <img src="repository/images/2.png" class="mx-auto d-block img-fluid">
        </div>
    </div><br>
    <div class="row">
        <div class="col-sm-12">
            <img src="repository/images/3.png" class="mx-auto d-block img-fluid">
        </div>
    </div><br>
    <div class="row">
        <div class="col-sm-12">
            <img src="repository/images/4.png" class="mx-auto d-block img-fluid">
        </div>
    </div><br>
    <div class="row">
        <div class="col-sm-12">
            <img src="repository/images/5.png" class="mx-auto d-block img-fluid">
        </div>
    </div><br>
</div>
    
    <div class="fixed-bottom">
        <a href="http://greetcards.tk/create">
            <i class="fas fa-plus-circle"></i>
        </a>
    </div> 
<?php

    $c_date = date('Y-m-d');
    $c_time = date("H:i:s");
    $sql = "INSERT INTO `status`(`date`, `time`, `page`, `pid`) VALUES ('$c_date', '$c_time', 'greetcards.tk/index.php', 'p1');"; 
    mysqli_query($mysqli,$sql);
    
include 'non-pages/footer.php';
?>